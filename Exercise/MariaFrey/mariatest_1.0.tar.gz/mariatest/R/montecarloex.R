nsim<-10000
n=25;p=.2;
cp=pbinom(c(0:n),n,p)
X=array(0,c(nsim,1))
for(i in 1:nsim){
  u=runif(1)
  X[i]=sum(cp<u)
}
hist(X,freq=F)
lines(1:n,dbinom(1:n,n,p),lwd=2)
